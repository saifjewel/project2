
<?php
session_start();

$err = "";


if (!isset($_SESSION['login_success'])) {
	$uri .= "/saif";			  
	header('Location: '.$uri.'/index.php'); // redirect to the login page if data not match. 
}



$me = $_SESSION['user'];
$position = "";

$servername = "localhost";
$username = "root";
$passw = "";
$dbname = "db_imhere";    // database name.

$conn = new mysqli($servername, $username, $passw, $dbname);  // connect to the database.

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);   // database connection problem or failed.
} 


$sql = "SELECT * FROM `tb_map_share` WHERE `receiver` = '$me' ORDER BY(`id`) DESC LIMIT 1"; //sql query.
$result= $conn ->query($sql);
if ($conn->query($sql) == TRUE) {
	
	while ($row = $result -> fetch_assoc()) {
		$position = $row['position'];
	}

}else{
	$err = "Unexpected Error! Please try later."; // if failed to execute query, it will show the error message.
}


$conn->close(); // close database connection.



if (!empty($position)) {
	$po = explode(" ",$position);

	$latitud = $po[0];
	$longitud = $po[1];
}

?>

<html>
<head>
	<title>Home</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style2.css">

	<script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>

	<style>
		html, body {
		  height: 100%;
		  margin: 0;
		  padding: 0;
		}
		#floating-panel {
		  position: absolute;
		  top: 10px;
		  left: 25%;
		  z-index: 5;
		  background-color: #fff;
		  padding: 5px;
		  border: 1px solid #999;
		  text-align: center;
		  font-family: 'Roboto','sans-serif';
		  line-height: 30px;
		  padding-left: 10px;
		}
	</style>
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<nav class="navbar navbar-inverse">
				  <div class="container-fluid">

				    <div class="navbar-header">
				      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
				        <span class="sr-only">Toggle navigation</span>
				        <span class="icon-bar"></span>
				        <span class="icon-bar"></span>
				        <span class="icon-bar"></span>
				      </button>
				      <a class="navbar-brand" href="home.php">I'm Here!!</a>
				    </div>

				    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				      <ul class="nav navbar-nav">
				        <li class="active"><a href="message.php">Messages<span class="sr-only">(current)</span></a></li>
				      </ul>
				      <ul class="nav navbar-nav navbar-right">
				        <!-- <li><a href="#">Add Contacts</a></li> -->
				        <li><a href="#"><?php echo $_SESSION['user']; ?></a></li>
				        <li><a class="btn btn-default" href="logout.php">Logout</a></li>
				      </ul>
				    </div>
				  </div>
				</nav>
			</div>
		</div>

		<div class="col-md-12">
			<div class="row">
				<div class="col-md-8" style="border: 3px solid #ccc">
					<h2>Map</h2>
					<div id="floating-panel">
						<b>Mode of Travel: </b>
						<select id="mode">
						  <option value="DRIVING">Driving</option>
						  <option value="WALKING">Walking</option>
						  <option value="BICYCLING">Bicycling</option>
						  <option value="TRANSIT">Transit</option>
						</select>
					</div>
					<div id="map" style="background:yellow; width: 100%; height: 80%;">

					</div>
				</div>
				<div class="col-md-4" style="background: #f6f6f6;">
					<div class="list-group">
						
					    <li class="list-group-item active"><h4 class="text-center">Message</h4></li>
					    
					    	<li class="list-group-item">
					    		<a href="">Mahmud</a>
					    	</li>
					    	<li class="list-group-item">
					    		<a href="">Yusuf</a>
					    	</li>
					    	<li class="list-group-item">
					    		<a href="">Alamgir</a>
					    	</li>				    

					</div>
				</div>
			</div>
		</div>
	</div>


	<script>
	  var map, infoWindow;

	  var latitud = <?php echo $latitud ?>;
	  var long = <?php echo $longitud ?>;

	  function initMap() {
	    var directionsDisplay = new google.maps.DirectionsRenderer;
	    var directionsService = new google.maps.DirectionsService;
	    var map = new google.maps.Map(document.getElementById('map'), {
	      zoom: 14
	    });
	    infoWindow = new google.maps.InfoWindow;

	    directionsDisplay.setMap(map);

	    calculateAndDisplayRoute(directionsService, directionsDisplay);
	    document.getElementById('mode').addEventListener('change', function() {
	      calculateAndDisplayRoute(directionsService, directionsDisplay);
	    });
	  }


	  function calculateAndDisplayRoute(directionsService, directionsDisplay) {
	    var selectedMode = document.getElementById('mode').value;
	    
	    if (navigator.geolocation) {
	        navigator.geolocation.getCurrentPosition(showPosition);
	    } else { 
	        handleLocationError(false, infoWindow, map.getCenter());
	    }

	    function showPosition(position) {
	        latitud_me = position.coords.latitude; 
	        long_me = position.coords.longitude;

	        directionsService.route({
	          origin: {lat: latitud_me, lng: long_me},  // Haight.
	          destination: {lat: latitud, lng: long},  // Ocean Beach. 
	          travelMode: google.maps.TravelMode[selectedMode]
	        }, function(response, status) {
	          if (status == 'OK') {
	            directionsDisplay.setDirections(response);
	          } else {
	            window.alert('Directions request failed due to ' + status);
	          }
	        });
	    }
	  }

	  function handleLocationError(browserHasGeolocation, infoWindow, pos) {
	    infoWindow.setPosition(pos);
	    infoWindow.setContent(browserHasGeolocation ?
	                          'Error: The Geolocation service failed.' :
	                          'Error: Your browser doesn\'t support geolocation.');
	    infoWindow.open(map);
	  }
	</script>
	<script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDJGOv0-6TJ7RY3x_UNCwdhV0r4QTj-lGQ&callback=initMap">
    </script>

</body>


</html>
