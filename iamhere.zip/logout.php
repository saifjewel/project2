<?php 
	session_start();
	
	session_unset();
	session_destroy(); 
	
	setcookie('site_user',$name,time()-10,"","", 0); //this piece of code are newly added.
	setcookie('site_u_pass',$pass,time()-10,"","", 0);

	$uri .= "/saif";			  
	header('Location: '.$uri.'/index.php');

?>