<?php
session_start();

$con = mysqli_connect('localhost','root');

if ($con)
{
  echo"connection successful";
}
else
{
  echo "no connection";
}
mysqli_select_db($con, 'imhere');

$first_name = $_POST['Firstname'];
$last_name = $_POST['Lastname'];
$email = $_POST['Email'];
$password = $_POST['Password'];

$q = "select * from reg where fname = '$first_name' , lname = '$last_name', email = '$email' && password = '$password'";
$result = mysqli_query($con,$q);
$num = mysqli_num_rows($result);

if ($num == 1)
{
  //echo "Duplicate Date";
  $_SESSION['username'] = $name;
  header('location:home.php');
}
else
{
  header('location:login.php');

}


 ?>
