<?php
session_start();
// header('location:login.php');
include 'config.php';

if (isset($_POST['submit'])) {
  $first_name = $_POST['firstname'];
  $last_name = $_POST['lastname'];
  $email = $_POST['email'];
  $password = $_POST['password'];

  $q = "SELECT  * FROM reg WHERE email = '$email'";
  $result = mysqli_query($con,$q);
  //$num = mysqli_num_rows($con,$result);

  if ($result)
  {
    echo "already exits";
  }
  else {
    $qy = "INSERT INTO reg ('fname', 'lname', 'email', 'password') VALUES ('$first_name','$last_name','$email','$password')";
    mysqli_query($con,$qy);
    if ($qy) {
      header('location: index.php');
    }
    else {
      echo "error reg";
    }
  }
}

 ?>
