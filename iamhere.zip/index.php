<?php session_start(); 

   $name = $pass = $nameEr = $passEr = $repassEr = $emailEr = "";           // variable.

   if (isset($_COOKIE['site_user']) && isset($_COOKIE['site_u_pass'])) {
      $name = $_COOKIE['site_user'];
      $pass = $_COOKIE['site_u_pass'];
      $_SESSION['login_success'] = 'yes';
      $_SESSION['user'] = $name;
   }
   if (isset($_SESSION['login_success']) == 'yes') {
      $uri .= "/saif";           
      header('Location: '.$uri.'/home.php'); // redirect to the another page if data match. 
   }

if ($_SERVER ["REQUEST_METHOD"] == "POST") {

    if (isset($_POST["login"])) {
      $name = test_input($_POST["username"]);
      if (!preg_match("/^[a-zA-Z0-9]*$/", $name)) {
         $_SESSION['name_err'] ="Only letters and numbers are allowed in username";
      }
      else{
         if (empty($name)) {
            $_SESSION['name_err'] ="Username field is empty.";
         }
         else{
            $_SESSION['username_Approve']=1;
         }  
      }


      $pass = $_POST["password"];
      $pass = stripcslashes( $pass );
      if (empty($pass)) {
         $_SESSION['password_err']="Password field is empty.";
      }
      else{
         try {
            if (preg_match('/[\'^$^%&*}{@#~?,!|=_+-`;:]/', $pass)) {
               $_SESSION['pass_Approve']= 1;
            }
            else{
               $_SESSION['error'] ="Incorrect input !";
            }
         } catch (Exception $e) {

            $_SESSION['error'] = "Incorrect input !";
            
         }
         
      }
    } 
    



     // Registration form input validation


    if (isset($_POST["registration"])) {

      $uname = test_input($_POST["uname"]);
      if (!preg_match("/^[a-zA-Z0-9]*$/", $uname)) {
        $nameEr ="Only letters and numbers are allowed in username.";
      }
      else{
        if (empty($uname)) {
          $nameEr="Username field is empty.";
        }
        else{
             if (preg_match('/^([a-z]+([0-9]+)*){1}$/i', $uname)) {
              $_SESSION['usernameApprove']=1;
            }
            else{
                 if (preg_match('/^([a-z]+([0-9a-z]+)*){1}$/i', $uname)) {
                $_SESSION['usernameApprove']=1;
              }
              else{
                  $nameEr ="Only letters and numbers are allowed";
              }
            }
           
        } 
      }


       $email = test_input($_POST["mail"]);
       if (empty($email)) {
        $emailEr = "E-mail field is empty.";
       }
       else{
         if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $_SESSION['emailApprove']= 1;
         }
         else{
           $emailEr = "This type of email address is not acceptable.";
         }
       }


      $pass = $_POST["pass"];
      $re_pass = $_POST["repass"];
      $pass = stripslashes( $pass );
      $re_pass = stripslashes( $re_pass );

      if (empty($pass) || empty($re_pass)) {
         $passEr="Password field is empty.";
      }
      else{

        if (strlen($pass)<6) {
           $passEr ="Password must be greater than 6 character.";
         }
         else{

           if ($pass == $re_pass) {
           
             if (preg_match('/[^$^%&*@#~?,!_+-;:]/', $pass)) {
                 $_SESSION['passApprove']= 1;
             }
             else{
                 $passEr ="Password have to contain at-least one special character.";
             }

           } else {
             $repassEr = "Password not matched.";
           }

         } 
      }
    }

    


  }

   function test_input($data){
      $data = trim($data);
      $data = stripcslashes($data);
      $data = htmlspecialchars($data);
      return $data;
   }

   if (!isset($_SESSION['submit']) && isset($_SESSION['username_Approve'])==1 && isset($_SESSION['pass_Approve'])==1) {
         // remove all session variables
      unset($_SESSION['username_Approve']);
      unset($_SESSION['pass_Approve']);

      
      $servername = "localhost";
      $username = "root";
      $passw = "";
      $dbname = "db_imhere";    // database name.
      
      $conn = new mysqli($servername, $username, $passw, $dbname);  // connect to the database.

      if ($conn->connect_error) {
          die("Connection failed");   // database connection problem or failed.
      } 

      $sql = "SELECT `username`, `password` FROM `tb_users` WHERE `username`='$name'  AND `password`= '$pass'"; //sql query.
      $result= $conn ->query($sql);
      if ($conn->query($sql) == TRUE) {         // successfully connected to the database.
            
            if ($result-> num_rows >0) {     // checking data row.if true than num_rows > 0.

               setcookie('site_user',$name,time()+(86400*10),"","", 0); //set cookie time for 10 days.
               setcookie('site_u_pass',$pass,time()+(86400*10),"","", 0); //set cookie time for 10 days.

               $_SESSION['user'] = $name;

               $_SESSION['login_success']='yes';

               $uri .= "/saif";           
               header('Location: '.$uri.'/home.php'); // redirect to the another page if data match. 
               exit;
               $_SESSION['submit'] = $_POST['submit'];

            } 
            else {
               $_SESSION['error'] = "Username or Password is incorrect."; // if username & password is not found in database show this error message.
            }

      } 
      else {
         $_SESSION['error'] = "Incorrect input in username or password field !"; // if query execution is fail, it will show the error message.
      }
      
      $conn->close(); // close database connection.
      }



      // Registration request handle
      if (!isset($_SESSION['submit']) && isset($_SESSION['usernameApprove'])==1 && isset($_SESSION['emailApprove'])==1 && isset($_SESSION['passApprove'])==1) {
            // remove all session variables
         unset($_SESSION['usernameApprove']);
         unset($_SESSION['emailApprove']);
         unset($_SESSION['passApprove']);

         
         $servername = "localhost";
         $username = "root";
         $passw = "";
         $dbname = "db_imhere";    // database name.
         
         $conn = new mysqli($servername, $username, $passw, $dbname);  // connect to the database.

         if ($conn->connect_error) {
             die("Connection failed.");   // database connection problem or failed.
         } 

         $sql = "INSERT INTO `tb_users`(`id`, `email`, `username`, `password`, `created_at`) VALUES (Null,'$email','$uname','$pass',CURRENT_TIMESTAMP)"; //sql query.
         
         if ($conn->query($sql) == TRUE) {         // successfully connected to the database.
               
                setcookie('site_user',$uname,time()+(86400*10),"","", 0); //set cookie time for 10 days.
                setcookie('site_u_pass',$pass,time()+(86400*10),"","", 0); //set cookie time for 10 days.

                $_SESSION['user'] = $uname;

                $_SESSION['login_success']='yes';

                $_SESSION['welcome_message'] = "Your account is ready. Have a nice day.";

                $uri .= "/saif";           
                header('Location: '.$uri.'/home.php'); // redirect to the another page if data match. 
                exit;
                $_SESSION['submit'] = $_POST['submit'];
         } 
         else {
            $_SESSION['error'] = "Error! We can't handle your request at this time. Try, later."; // if query execution is fail, it will show the error message.
         }
         
         $conn->close(); // close database connection.
      }
      
?>

<!DOCTYPE html>
<html>
<head>
  <title>Sign-Up/Login Form</title>
  <link href='https://fonts.googleapis.com/css?family=Titillium+Web:400,300,600' rel='stylesheet' type='text/css'>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
  <link rel="stylesheet" href="css/style.css">
</head>

<body>

  <?php if (isset($_SESSION['name_err']) || isset($_SESSION['password_err']) || isset($_SESSION['error']) || !empty($nameEr) || !empty($emailEr) || !empty($passEr) || !empty($repassEr)) { ?>
     <div id="snackbar-danger">
      <ul>
        <?php 

          if (isset($_SESSION['name_err'])) {
             echo '<li>'.$_SESSION['name_err']."</li>";

             unset($_SESSION['name_err']);
          } 

          if (isset($_SESSION['password_err'])) {
             echo '<li>'.$_SESSION['password_err']."</li>";

             unset($_SESSION['password_err']);
          }

          if (isset($_SESSION['error'])) {
             echo '<li>'.$_SESSION['error']."</li>";

             unset($_SESSION['error']);
          }

          if (!empty($nameEr)) {
             echo '<li>'.$nameEr."</li>";
          } 

          if (!empty($emailEr)) {
             echo '<li>'.$emailEr."</li>";
          } 

          if (!empty($passEr)) {
             echo '<li>'.$passEr."</li>";
          } 

          if (!empty($repassEr)) {
             echo '<li>'.$repassEr."</li>";
          } 
         ?>
      </ul>
     </div>
  <?php } ?>

  <div class="form">
      <ul class="tab-group">
          <li class="tab active"><a href="#signup">Sign Up</a></li>
          <li class="tab"><a href="#login">Log In</a></li>
      </ul>



    <div class="tab-content">
      <div id="signup">
            <h1>Sign Up for Free</h1>
          <form action="" method="POST">

            <div class="top-row">
              <div class="field-wrap">
                <label>
                  Username<span class="req">*</span>
                </label>
                <input type="text" name="uname" class="form-control" required autocomplete="off" />
              </div>

              <div class="field-wrap">
                <label>
                  Email Address<span class="req">*</span>
                </label>
                <input type="text" name="mail" class="form-control" required autocomplete="off"/>
              </div>
            </div>

            <div class="field-wrap">
              <label>
                Enter A Password<span class="req">*</span>
              </label>
                <input type="password" name="pass" class="form-control" required autocomplete="off"/>
            </div>
            <div class="field-wrap">
              <label>
                Re-enter The Password<span class="req">*</span>
              </label>
                <input type="password" name="repass" class="form-control" required autocomplete="off"/>
            </div>
              <button type="submit" name="registration" class="button button-block">Get Started</button>
          </form>
      </div>

      <div id="login">
        <h1>Welcome Back!</h1>
          <form action="" method="post">
                <div class="field-wrap">
                    <label>
                        Username<span class="req">*</span>
                    </label>
                      <input type="text" name="username" required autocomplete="off"/>
                </div>
                <div class="field-wrap">
                  <label>
                    Password<span class="req">*</span>
                  </label>
                    <input type="password" name="password" required autocomplete="off"/>
                </div>
                <p class="forgot"><a href="#">Forgot Password?</a></p>
                <button type="submit" name="login" class="button button-block">Log In</button>
          </form>
      </div>

    </div><!-- tab-content -->

  </div> <!-- /form -->

    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
    <script  src="js/index.js"></script>

    <script>

        if (document.getElementById("snackbar-danger")) {
          var x = document.getElementById("snackbar-danger")
          x.className = "show";
          setTimeout(function(){ x.className = x.className.replace("show", ""); }, 9000);
        } 
        if (document.getElementById("snackbar-success")) {
          var x = document.getElementById("snackbar-success")
          x.className = "show";
          setTimeout(function(){ x.className = x.className.replace("show", ""); }, 9000);
        }

    </script>

</body>
</html>
