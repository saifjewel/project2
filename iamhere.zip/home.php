
<?php
session_start();

$err = "";


if (!isset($_SESSION['login_success'])) {
	$uri .= "/saif";			  
	header('Location: '.$uri.'/index.php'); // redirect to the login page if data not match. 
}




if ($_SERVER["REQUEST_METHOD"] == "POST") {

	if (empty($_POST["contact"])) {
	    $_SESSION['contactErr'] = "Error! Select at least one contact.";
	} else {
		$contact = $_POST["contact"];
		$_SESSION['conApprove'] = "yes";
	}

	if (empty($_POST["lnla"])) {
		$_SESSION['lnlaErr'] = "Error! There is a problem to share your location. Please reload this page.";
	} else {
		$lnla = test_input($_POST["lnla"]);
		$_SESSION['lnlaApprove'] = "yes";
	}


	if (!isset($_SESSION['submit']) && isset($_SESSION['conApprove']) == "yes" && isset($_SESSION['lnlaApprove']) == "yes") {
		
		$servername = "localhost";
		$username = "root";
		$passw = "";
		$dbname = "db_imhere";    // database name.

		$sender = $_SESSION['user'];
		
		$conn = new mysqli($servername, $username, $passw, $dbname);  // connect to the database.

		if ($conn->connect_error) {
		    die("Connection failed: " . $conn->connect_error);   // database connection problem or failed.
		} 

		foreach ($contact as $receiver) {
			$sql = "INSERT INTO `tb_map_share`(`id`, `sender`, `receiver`, `position`, `created_at`) VALUES (Null,'$sender','$receiver','$lnla',CURRENT_TIMESTAMP)"; //sql query.
		
			if ($conn->query($sql) == TRUE) {
				$_SESSION['success'] = "Map share Successfully";
			}else{
				$err = "Unexpected Error! Please try later."; // if failed to execute query, it will show the error message.
			}
		}
		
			$conn->close(); // close database connection.

			$uri .= "/saif";			  
			header('Location: '.$uri.'/home.php'); // redirect to the another page if data match. 
			exit;
			$_SESSION['submit'] = $_POST['submit'];

		}
	
	

}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

?>

<html>
<head>
	<title>Home</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style2.css">

	<script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
</head>
<body>
	<div class="container">
		
		<?php if (isset($_SESSION['contactErr']) || isset($_SESSION['lnlaErr']) || !empty($err)) { ?>
			<div id="snackbar-danger">
		    <?php 

		    	if (isset($_SESSION['contactErr'])) {
		    		echo '<p>'.$_SESSION['contactErr']."</p>";

		    		unset($_SESSION['contactErr']);
		    	} 

		    	if (isset($_SESSION['lnlaErr'])) {
		    		echo '<p>'.$_SESSION['lnlaErr']."</p>";

		    		unset($_SESSION['lnlaErr']);
		    	} 

		    	if (!empty($err)) {
		    		echo '<p>'.$err."</p>";
		    	}

		     ?>
		</div>
		<?php } ?>


		<?php 
			if (isset($_SESSION['success'])) {
		?>
			<div id="snackbar-success">
			<?php 
			
					echo '<p>'.$_SESSION['success']."</p>";

					unset($_SESSION['success']);
			?>
			</div>
		<?php 
			}
		 ?>

		 <?php 
		 	if (isset($_SESSION['welcome_message'])) {
		 ?>
		 	<div id="snackbar-success">
		 	<?php 
		 	
		 			echo '<p>'.$_SESSION['welcome_message']."</p>";

		 			unset($_SESSION['welcome_message']);
		 	?>
		 	</div>
		 <?php 
		 	}
		  ?>

		<div class="row">
			<div class="col-md-12">
				<nav class="navbar navbar-inverse">
				  <div class="container-fluid">

				    <div class="navbar-header">
				      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
				        <span class="sr-only">Toggle navigation</span>
				        <span class="icon-bar"></span>
				        <span class="icon-bar"></span>
				        <span class="icon-bar"></span>
				      </button>
				      <a class="navbar-brand" href="home.php">I'm Here!!</a>
				    </div>

				    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				      <ul class="nav navbar-nav">
				        <li class="active"><a href="message.php">Messages<span class="sr-only">(current)</span></a></li>
				      </ul>
				      <ul class="nav navbar-nav navbar-right">
				        <!-- <li><a href="#">Add Contacts</a></li> -->
				        <li><a href="#"><?php echo $_SESSION['user']; ?></a></li>
				        <li><a class="btn btn-default" href="logout.php">Logout</a></li>
				      </ul>
				    </div>
				  </div>
				</nav>
			</div>
		</div>

		<div class="col-md-12">
			<div class="row">
				<div class="col-md-8" style="border: 3px solid #ccc">
					<h2>Map</h2>
					<div id="map" style="background:yellow; width: 100%; height: 80%;">

					</div>
				</div>
				<div class="col-md-4" style="background: #f6f6f6;">
					<div class="list-group">
						
					    <li class="list-group-item active"><h4 class="text-center">Contacts</h4></li>
					    <form action="" method="POST">
					    	<?php 

					    		$servername = "localhost";
					    		$username = "root";
					    		$passw = "";
					    		$dbname = "db_imhere";

					    		$conn = new mysqli($servername, $username, $passw, $dbname);  // connect to the database.

					    		if ($conn->connect_error) {
					    		    die("Connection failed:.");   // database connection problem or failed.
					    		} 

					    		$sql = "SELECT `username` FROM `tb_users`"; //sql query.
					    		$result= $conn ->query($sql);
					    		if ($conn->query($sql) == TRUE) {         // successfully connected to the database.
					    		      
					    		      if ($result-> num_rows >1) {     // checking data row.if true than num_rows > 0.
					    		         foreach ($result as $value) {
					    		         	if ($value['username'] != $_SESSION['user']) {
				    		         		?>
				    		         			<li class="list-group-item">
				    		         				<input type="checkbox" name="contact[]" value="<?php echo $value['username']; ?>"><?php echo $value['username']; ?> 
				    		         			</li>
				    		         		<?php
					    		         	}
					    		         }
					    		         ?>

					    		         <input type="hidden" name="lnla" id="lnglat" value="">
					    		         <button type="submit" class="btn btn-info snbtn">Send</button>

					    		         <?php

					    		      }
					    		}

					    	 ?>
					    </form>

					</div>
				</div>
			</div>
		</div>
	</div>


	<script>
	      var map, infoWindow;

	      function initMap() {
	        map = new google.maps.Map(document.getElementById('map'), {
	          zoom: 14
	        });
	        infoWindow = new google.maps.InfoWindow;

	        if (navigator.geolocation) {
	          navigator.geolocation.getCurrentPosition(function(position) {
	            var pos = {
	              lat: position.coords.latitude,
	              lng: position.coords.longitude
	            };

	            document.getElementById("lnglat").value = position.coords.latitude+" "+position.coords.longitude;

	            infoWindow.setPosition(pos);
	            infoWindow.setContent('You are here');
	            infoWindow.open(map);
	            map.setCenter(pos);
	            
	          }, function() {
	            handleLocationError(true, infoWindow, map.getCenter());
	          });
	        } else {

	          handleLocationError(false, infoWindow, map.getCenter());
	        }
	      }

	      function handleLocationError(browserHasGeolocation, infoWindow, pos) {
	        infoWindow.setPosition(pos);
	        infoWindow.setContent(browserHasGeolocation ?
	                              'Error: The Geolocation service failed.' :
	                              'Error: Your browser doesn\'t support geolocation.');
	        infoWindow.open(map);
	      }
	</script>
	    <script async defer
	    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDJGOv0-6TJ7RY3x_UNCwdhV0r4QTj-lGQ&callback=initMap">
	    </script>


	<script>

	    if (document.getElementById("snackbar-danger")) {
	    	var x = document.getElementById("snackbar-danger")
	    	x.className = "show";
	    	setTimeout(function(){ x.className = x.className.replace("show", ""); }, 6000);
	    } 
	    if (document.getElementById("snackbar-success")) {
	    	var x = document.getElementById("snackbar-success")
	    	x.className = "show";
	    	setTimeout(function(){ x.className = x.className.replace("show", ""); }, 6000);
	    }

	</script>

</body>
</html>
