-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 16, 2018 at 05:34 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_imhere`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_map_share`
--

CREATE TABLE `tb_map_share` (
  `id` int(11) NOT NULL,
  `sender` varchar(120) NOT NULL,
  `receiver` varchar(120) NOT NULL,
  `position` varchar(150) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_map_share`
--

INSERT INTO `tb_map_share` (`id`, `sender`, `receiver`, `position`, `created_at`) VALUES
(1, 'Saif', 'ababil', '23.748995 90.407595', '2018-04-02 06:45:00'),
(4, 'Ababil', 'saif', '23.755659899999998 90.38085960000001', '2018-04-02 06:57:12'),
(5, 'Ababil', 'saif', '23.7556484 90.3809034', '2018-04-02 07:08:14'),
(6, 'Ababil', 'saif', '23.810332 90.4125181', '2018-04-02 09:22:48'),
(7, 'Saif', 'ababil', '23.752403299999997 90.3776888', '2018-04-02 09:24:20'),
(8, 'Saif', 'ababil', '23.752355899999998 90.37773039999999', '2018-04-02 09:25:00'),
(9, 'Saif', 'ababil', '23.7523543 90.3777277', '2018-04-02 09:25:31'),
(10, 'Saif', 'ababil', '23.752355899999998 90.37773039999999', '2018-04-02 09:26:55'),
(11, 'Saif', 'ababil', '23.7523533 90.377731', '2018-04-02 09:28:48'),
(12, 'Ababil', 'saif', '23.810332 90.4125181', '2018-04-02 09:30:41'),
(13, 'Ababil', 'saif', '', '2018-04-02 09:44:27'),
(14, 'Saif', 'ababil', '23.7523539 90.3777291', '2018-04-02 09:44:37'),
(15, 'Ababil', 'saif', '23.7523543 90.3777277', '2018-04-02 09:50:54'),
(16, 'Saif', 'ababil', '23.7523533 90.3777291', '2018-04-02 09:51:27'),
(17, 'Ababil', 'saif', '23.752355899999998 90.3777277', '2018-04-02 09:51:36'),
(18, 'ab', 'Ababil', '23.756884 90.3685922', '2018-04-09 02:35:03'),
(19, 'Saif', 'Ababil', '23.7556302 90.3809136', '2018-04-09 05:19:58'),
(20, 'sa', 'Saif', '23.755274 90.3808774', '2018-04-09 05:20:33'),
(21, 'Saif', 'Ababil', '23.755135 90.380675', '2018-04-09 05:45:27'),
(22, 'Saif', 'Ababil', '23.755972099999997 90.38049099999999', '2018-04-09 06:13:18'),
(23, 'Ababil', 'Saif', '23.7557074 90.380859', '2018-04-09 06:34:06'),
(24, 'Saif', 'Ababil', '23.7525709 90.3774587', '2018-04-09 10:26:06'),
(25, 'Ababil', 'Saif', '23.810332 90.4125181', '2018-04-09 10:27:55'),
(26, 'Ababil', 'Saif', '23.810332 90.4125181', '2018-04-09 10:28:26');

-- --------------------------------------------------------

--
-- Table structure for table `tb_users`
--

CREATE TABLE `tb_users` (
  `id` int(11) NOT NULL,
  `email` varchar(125) NOT NULL,
  `username` varchar(120) NOT NULL,
  `password` varchar(120) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_users`
--

INSERT INTO `tb_users` (`id`, `email`, `username`, `password`, `created_at`) VALUES
(1, 'saif@gmail.com', 'Saif', 's@if123', '2018-04-01 18:42:34'),
(2, 'ababil@gmail.com', 'Ababil', 'a@123', '2018-04-02 06:42:46'),
(3, 'ab@cd.com', 'ab', 'a1234567', '2018-04-09 02:08:51'),
(4, 's@a.com', 'sa', 'a1234567', '2018-04-09 05:18:20');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_map_share`
--
ALTER TABLE `tb_map_share`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_users`
--
ALTER TABLE `tb_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_map_share`
--
ALTER TABLE `tb_map_share`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `tb_users`
--
ALTER TABLE `tb_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
